export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["favicon.png","GIF/house1.gif","GIF/oil.gif","GIF/void.gif","GIF/void.webp","GIF/water.gif","PNG/flowers1.png","PNG/flowers2.png","PNG/grass1.png","PNG/grass2.png","PNG/grass3.png","PNG/grass4.png","PNG/ground1.png","PNG/ground2.png","PNG/ground3.png","PNG/ground4.png","PNG/house1.png","PNG/plant1.png","PNG/plant2.png","PNG/plant4.png","PNG/plant5.png","PNG/plant7.png","PNG/plant8.png","PNG/remove.png","PNG/rock1.png","PNG/rock2.png","PNG/rock3.png","PNG/rock4.png","PNG/rock5.png","PNG/sign1.png","PNG/tree1.png","PNG/tree2.png","PNG/tree3.png","PNG/tree4.png","PNG/tree5.png","PNG/tree6.png","PNG/tree7.png","PNG/tree8.png","PNG/water1.png"]),
	mimeTypes: {".png":"image/png",".gif":"image/gif",".webp":"image/webp"},
	_: {
		client: {"start":"_app/immutable/entry/start.53914c59.js","app":"_app/immutable/entry/app.34069954.js","imports":["_app/immutable/entry/start.53914c59.js","_app/immutable/chunks/scheduler.8b5db029.js","_app/immutable/chunks/singletons.0104e7ea.js","_app/immutable/entry/app.34069954.js","_app/immutable/chunks/scheduler.8b5db029.js","_app/immutable/chunks/index.14c2e2ac.js"],"stylesheets":[],"fonts":[]},
		nodes: [
			__memo(() => import('../output/server/nodes/0.js')),
			__memo(() => import('../output/server/nodes/1.js')),
			__memo(() => import('../output/server/nodes/2.js'))
		],
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			},
			{
				id: "/api",
				pattern: /^\/api\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('../output/server/entries/endpoints/api/_server.js'))
			}
		],
		matchers: async () => {
			
			return {  };
		}
	}
}
})();

export const prerendered = new Set([]);
