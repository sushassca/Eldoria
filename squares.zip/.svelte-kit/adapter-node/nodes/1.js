

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.6145c8c1.js","_app/immutable/chunks/scheduler.8b5db029.js","_app/immutable/chunks/index.14c2e2ac.js","_app/immutable/chunks/singletons.ea461144.js"];
export const stylesheets = [];
export const fonts = [];
