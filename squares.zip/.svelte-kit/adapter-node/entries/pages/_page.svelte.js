import { c as create_ssr_component, d as add_attribute, f as each, e as escape, h as null_to_empty } from "../../chunks/ssr.js";
import { io } from "socket.io-client";
const _page_svelte_svelte_type_style_lang = "";
const css = {
  code: ".center.svelte-r9md3{display:grid;align-items:center;justify-items:center}.wrapper.svelte-r9md3{height:100%;width:100%}#map.svelte-r9md3{display:grid}.cell.svelte-r9md3{border:1px solid white;background-color:black;padding:8px;text-align:center;box-sizing:border-box;display:grid;justify-content:center;align-items:center;color:white;text-transform:uppercase;font-family:'Roboto', Times, serif}.f1.svelte-r9md3{background-color:green}.f2.svelte-r9md3{background-color:grey}",
  map: null
};
const height = 500;
const width = 500;
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let loops;
  const socket = io();
  socket.on("eventFromServer", (message) => {
    console.log(message);
  });
  let data = null;
  $$result.css.add(css);
  loops = Array.from({ length: 0 }, (_, index) => index);
  return `<div${add_attribute("style", `grid-template-columns: repeat(1, 1fr);`, 0)} class="wrapper center svelte-r9md3"><div id="map"${add_attribute("style", `grid-template-columns: repeat(${data?.length}, 1fr); width: ${width}px; height: ${height}px;`, 0)} class="svelte-r9md3">${each(loops, (row) => {
    return ` ${each(loops, (col) => {
      return ` <div class="${escape(null_to_empty(`cell center ${data[row][col][0]}`), true) + " svelte-r9md3"}">${escape(data[row][col][0])}-${escape(data[row][col][1])}</div>`;
    })}`;
  })}</div> </div>`;
});
export {
  Page as default
};
